import lib.naverNewsCrawler as nnc

# 검색어 입력
keyword = input("검색어 : ").strip()
#keyword = "맛집"

# API 호출 결과 전송된 JSON이 없거나, 전송된 JSON에 검색 결과가 없을 때까지
# 검색 결과를 JSON의 list로 저장 후 검색 API 추가 호출

# 검색 결과를 저장할 list 초기화
resultAll = []

# 첫 검색 API 호출
start = 1
display = 10
resultJSON = nnc.searchNaverNews(keyword, start, display)

while (resultJSON != None) and (resultJSON['display'] > 0):
    # 응답데이터 정리하여 리스트 저장
    nnc.setNewsSearchResult(resultAll, resultJSON)
 
    # 다음 검색 API 호출을 위한 파라미터 조정
    start += resultJSON['display']
    
    # API 호출
    resultJSON = nnc.searchNaverNews(keyword, start, display)
    
    # API 호출 성공 여부 출력
    if resultJSON != None:
        print(f"{keyword} [{start}] : Search Request Success")
    else:
        print(f"{keyword} [{start}] : Error ~~~~")

# 리스트를 csv 파일로 저장
filename = f"./data/{keyword}_naver_news.csv"
nnc.saveSearchResult_CSV(resultAll, filename)