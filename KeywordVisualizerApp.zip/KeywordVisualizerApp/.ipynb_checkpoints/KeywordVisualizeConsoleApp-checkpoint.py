import mylib.myTextMining as tm
from konlpy.tag import Okt, Komoran

# 코퍼스 로딩
#input_filename = "daum_movie_review.csv"
input_filename = "맛집_naver_news.csv"
corpus_list = tm.load_corpus_from_csv("./data/" + input_filename, "description")

# 빈도수 추출
# my_tokenizer = Okt().pos
# my_tags = ['Noun', 'Adjective', 'Verb']

my_tokenizer = Komoran().pos
my_tags = ['NNG', 'NNP', 'VV', 'VA']

my_stopwords = ['불량', '불법', '이상', '이물질', '청결']
counter = tm.analyze_word_freq(corpus_list, my_tokenizer, my_tags, my_stopwords)
#tm.visualize_barchart(counter, "다음 영화 리뷰 키워드 분석", "빈도수", "키워드")
tm.visualize_wordcloud(counter)
